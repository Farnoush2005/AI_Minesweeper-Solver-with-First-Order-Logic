# =========================================================================
# Project 4: Minesweeper Solver using First-Order Logic
# Course: Artificial Intelligence

# University of Isfahan
# Group Members: Farnoush Pourshaban, Yeganeh Rastegari, Farzaneh Salimi
# Student ID: 4024023007, 4014013040, 4014013059
# =========================================================================

# Setting up pyDatalog terms
# (Note for TA: VS Code Linter/Pylance might show yellow lines under these, 
# but it's normal for pyDatalog since they are created dynamically!)

import pygame
import time
import random
from pyDatalog import pyDatalog
from src.minesweeper import MineSweeper


pyDatalog.create_terms('R, C, R1, C1, R2, C2, N, F, H')
pyDatalog.create_terms('Adjacent, CellValue, Safe, Mine, Hidden, FlaggedCount, HiddenCount')

AGENT_UNKNOWN = -1
AGENT_FLAGGED = -2

# Dictionary to keep track of facts from the previous turn so we can retract them
previous_facts = {
    'Hidden': set(),
    'CellValue': set(),
    'FlaggedCount': set(),
    'HiddenCount': set()
}

# =========================================================================
# Logic & Rules Setup
# =========================================================================

def init_static_facts(rows, cols):
    """
    Generate static facts at the beginning of the game.
    Mainly used to define which cells are adjacent to each other.
    """
    for r1 in range(rows):
        for c1 in range(cols):
            for dr in [-1, 0, 1]:
                for dc in [-1, 0, 1]:
                    if dr == 0 and dc == 0:
                        continue
                    r2, c2 = r1 + dr, c1 + dc
                    if 0 <= r2 < rows and 0 <= c2 < cols:
                        # Using '+' to assert the Fact in pyDatalog
                        + Adjacent(r1, c1, r2, c2)

def init_rules():
    """
    Defining the inference rules based on the project document.
    """
    # Safe Rule:
    # If a cell's number (N) equals the number of flagged neighbors (F),
    # then all of its remaining hidden neighbors are safe to click.
    Safe(R2, C2) <= (
        CellValue(R1, C1, N) & 
        FlaggedCount(R1, C1, F) & 
        (N == F) & 
        Adjacent(R1, C1, R2, C2) & 
        Hidden(R2, C2)
    )
    
    # Mine Rule:
    # If a cell's number (N) equals the total number of its unrevealed 
    # neighbors (H) (flags + hidden), then all those hidden neighbors are mines.
    Mine(R2, C2) <= (
        CellValue(R1, C1, N) & 
        HiddenCount(R1, C1, H) & 
        (N == H) & 
        Adjacent(R1, C1, R2, C2) & 
        Hidden(R2, C2)
    )

def update_knowledge_base(agent_board, rows, cols):
    """
    Translates the current board state into dynamic facts.
    """
    global previous_facts
    
    # 1. Retract old facts from the previous iteration (using '-')
    for r, c in previous_facts['Hidden']:
        - Hidden(r, c)
    for r, c, val in previous_facts['CellValue']:
        - CellValue(r, c, val)
    for r, c, f in previous_facts['FlaggedCount']:
        - FlaggedCount(r, c, f)
    for r, c, h in previous_facts['HiddenCount']:
        - HiddenCount(r, c, h)
        
    # Reset the tracking dictionary
    previous_facts = {
        'Hidden': set(),
        'CellValue': set(),
        'FlaggedCount': set(),
        'HiddenCount': set()
    }
    
    # 2. Assert new facts based on the updated board
    for (r, c), val in agent_board.items():
        if val == AGENT_UNKNOWN:
            + Hidden(r, c)
            previous_facts['Hidden'].add((r, c))
        elif val >= 0:
            + CellValue(r, c, val)
            previous_facts['CellValue'].add((r, c, val))
            
            # Count flagged and completely hidden neighbors
            flagged = 0
            hidden = 0
            for dr in [-1, 0, 1]:
                for dc in [-1, 0, 1]:
                    if dr == 0 and dc == 0: continue
                    nr, nc = r + dr, c + dc
                    if (nr, nc) in agent_board:
                        n_val = agent_board[(nr, nc)]
                        if n_val == AGENT_FLAGGED:
                            flagged += 1
                        elif n_val == AGENT_UNKNOWN:
                            hidden += 1
                            
            + FlaggedCount(r, c, flagged)
            previous_facts['FlaggedCount'].add((r, c, flagged))
            
            # H = total unrevealed neighbors (hidden + flagged)
            total_unrevealed = hidden + flagged
            + HiddenCount(r, c, total_unrevealed)
            previous_facts['HiddenCount'].add((r, c, total_unrevealed))

def query_solver():
    """
    Query the pyDatalog engine to find safe moves and mines.
    """
    safe_moves = set()
    mine_moves = set()
    
    # Query for safe cells
    ans_safe = Safe(R, C)
    if ans_safe:
        for r, c in ans_safe.data: # .data is safer to iterate over
            safe_moves.add((r, c))
            
    # Query for definitely mine cells
    ans_mine = Mine(R, C)
    if ans_mine:
        for r, c in ans_mine.data:
            mine_moves.add((r, c))
            
    return list(safe_moves), list(mine_moves)

# =========================================================================
# Deadlock Handling (Smart Guessing)
# =========================================================================

def get_safest_guess(agent_board, rows, cols):
    """
    When FOL gets stuck, we need to guess.
    This calculates a simple risk factor for fringe cells to pick the safest bet.
    """
    best_guess = None
    min_risk = float('inf')
    
    hidden_cells = [(r, c) for (r, c), v in agent_board.items() if v == AGENT_UNKNOWN]
    if not hidden_cells:
        return None
        
    for hr, hc in hidden_cells:
        max_adj_risk = 0.0
        is_fringe = False
        
        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                if dr == 0 and dc == 0: continue
                nr, nc = hr + dr, hc + dc
                if 0 <= nr < rows and 0 <= nc < cols:
                    n_val = agent_board.get((nr, nc))
                    if n_val is not None and n_val >= 0:
                        is_fringe = True
                        
                        flagged = 0
                        unknown = 0
                        for ddr in [-1, 0, 1]:
                            for ddc in [-1, 0, 1]:
                                if ddr == 0 and ddc == 0: continue
                                nnr, nnc = nr + ddr, nc + ddc
                                if 0 <= nnr < rows and 0 <= nnc < cols:
                                    v = agent_board.get((nnr, nnc))
                                    if v == AGENT_FLAGGED:
                                        flagged += 1
                                    elif v == AGENT_UNKNOWN:
                                        unknown += 1
                        
                        if unknown > 0:
                            # Risk = remaining mines around cell / remaining unknown cells
                            risk = (n_val - flagged) / unknown
                            if risk > max_adj_risk:
                                max_adj_risk = risk
                                
        # Only evaluate fringe cells (cells touching the numbers)
        if is_fringe:
            if max_adj_risk < min_risk:
                min_risk = max_adj_risk
                best_guess = (hr, hc)
                
    if best_guess:
        return best_guess
    
    # If no fringe cells are found, just pick a random one
    return random.choice(hidden_cells)

# =========================================================================
# Main Game Loop
# =========================================================================

def prolog_solver(game):
    # Clear pyDatalog completely so it's fresh for each test case
    pyDatalog.clear()
    
    global previous_facts
    previous_facts = {
        'Hidden': set(), 'CellValue': set(), 'FlaggedCount': set(), 'HiddenCount': set()
    }
    
    # Initial setup
    init_static_facts(game.rows, game.cols)
    init_rules()
    
    agent_board = {}
    for r in range(game.rows):
        for c in range(game.cols):
            agent_board[(r, c)] = AGENT_UNKNOWN

    start_r, start_c = game.get_start_pos()
    print(f"Starting at guaranteed safe position: {start_r}, {start_c}")
    
    # First move is always safe based on environment constraints
    start_val = game.reveal(start_r, start_c)
    agent_board[(start_r, start_c)] = start_val if start_val is not None else 0
    
    running = True
    while running and not game.game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # 1. Update logic
        update_knowledge_base(agent_board, game.rows, game.cols)

        # 2. Inference
        safe_moves, mine_moves = query_solver()
        move_made = False

        # 3. Apply moves (Flag mines first, then reveal safe cells)
        for r, c in mine_moves:
            if agent_board[(r, c)] == AGENT_UNKNOWN:
                game.flag(r, c)
                agent_board[(r, c)] = AGENT_FLAGGED
                move_made = True

        for r, c in safe_moves:
            if agent_board[(r, c)] == AGENT_UNKNOWN:
                val = game.reveal(r, c)
                agent_board[(r, c)] = val if val is not None else 0
                move_made = True
        
        # 4. Handle Deadlocks (if no logical moves are found)
        if not move_made and not game.game_over:
            print("Logical deadlock! Attempting a smart guess...")
            guess_move = get_safest_guess(agent_board, game.rows, game.cols)
            if guess_move:
                r, c = guess_move
                val = game.reveal(r, c)
                agent_board[(r, c)] = val if val is not None else 0

        game.render()
        time.sleep(0.05) # Delay for better visualization

    # Keep the window open when the game ends
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        game.render()

if __name__ == "__main__":
    ms = MineSweeper(rows=45, cols=80, mines=200, seed=-1, auto_flood_fill=False)
    prolog_solver(ms)